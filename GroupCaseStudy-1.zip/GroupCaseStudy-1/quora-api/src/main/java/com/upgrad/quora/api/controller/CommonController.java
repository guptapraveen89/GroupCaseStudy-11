package com.upgrad.quora.api.controller;

import com.upgrad.quora.service.business.UserEntityService;
import com.upgrad.quora.service.entity.UsersEntity;
import org.hibernate.dialect.PostgreSQL9Dialect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.awt.*;

@RestController
@RequestMapping
public class CommonController {

    @Autowired
    UserEntityService userEntityService;
    @RequestMapping(method = RequestMethod.GET, value = "/userProfile/{userId}")
    @ResponseBody
public ResponseEntity userProfile(@PathVariable final Integer userId) {
        userEntityService.getUserEntity(userId);
return  new ResponseEntity(HttpStatus.CREATED);
    }
}
