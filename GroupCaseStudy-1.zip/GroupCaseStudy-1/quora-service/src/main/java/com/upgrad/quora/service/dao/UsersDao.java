package com.upgrad.quora.service.dao;

import com.upgrad.quora.service.entity.UsersEntity;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

@Repository
public class UsersDao {

@PersistenceContext
private EntityManager entityManager;

    public UsersEntity getUser(final Integer id) {
try {
return entityManager.createNamedQuery("userById", UsersEntity.class).setParameter("id",id).getSingleResult();
}
catch (NoResultException nre) {
    return null;
}
    }
}
