package com.upgrad.quora.service.entity;

public class QuestionEntity {
}
